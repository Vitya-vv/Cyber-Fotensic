# Security Policy

Cyber Forensic is an educational browser game, not a production security tool.

## Reporting a vulnerability

Please avoid posting sensitive details publicly. Open a private report through GitHub's repository security reporting feature if it is enabled; otherwise contact the repository owner directly.

Do not submit real credentials, personal information, or confidential incident data in an issue.
