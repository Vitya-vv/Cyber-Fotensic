# Cyber Forensic

A browser-based cybersecurity investigation game for learning incident response and attack-chain reasoning.

The computer acts as the **Incident Captain**. Investigate an incident, use clues and tools, and uncover a secret four-stage attack chain before the turn limit runs out.

## Features

- **Start new incident** — investigate a hidden attack chain.
- **Pentested** — explore the offensive/security-testing game mode.
- **Company** — access the company/career area.
- **Walkthrough tutorial** — learn the core interaction loop.
- **Rules & how to play** — review game instructions.
- **Study all cards** — browse the learning-card reference.
- Dark cybersecurity-themed interface with responsive styling.

## Run locally

This is a self-contained browser game. No package manager, build step, or server is required.

1. Download or clone this repository.
2. Open `index.html` in a modern browser.
3. Select a mode from the main menu.

For a local HTTP server, run from the repository directory:

```bash
python -m http.server 8000
```

Then open http://localhost:8000.

## Project structure

- `index.html` — the game and its embedded styling and scripts.
- `CONTRIBUTING.md` — contribution workflow and quality guidelines.
- `SECURITY.md` — security reporting guidance.
- `.gitignore` — common local/editor artifacts to exclude.

## Educational and content note

This is a learning implementation inspired by published Cyber Forensic game rules. The learning edition uses original explanatory text and UI and does not reproduce the original card artwork or full copyrighted card text. It is intended for educational use, not as a real incident-response or penetration-testing tool.

## Roadmap ideas

- Add automated browser-based smoke tests.
- Improve keyboard navigation and accessibility.
- Separate the inline CSS and JavaScript into maintainable files.
- Add more original practice scenarios and debriefs.
- Document game mechanics and known limitations.

## License

No license has been specified yet. Until a license is added, assume normal copyright restrictions apply; do not assume the code is open source or freely reusable.
