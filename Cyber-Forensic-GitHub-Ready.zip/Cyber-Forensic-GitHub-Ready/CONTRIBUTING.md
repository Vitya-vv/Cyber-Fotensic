# Contributing

Thank you for helping improve Cyber Forensic.

## Before making changes

- Keep the game usable as a static browser project unless a change explicitly requires otherwise.
- Prefer original explanatory content and artwork.
- Do not add copyrighted card artwork or reproduce substantial card text without permission.
- Keep cybersecurity scenarios safe and focused on learning, investigation, and defensive reasoning.

## Suggested workflow

1. Create a feature branch.
2. Make a focused change.
3. Test `index.html` in a current browser.
4. Verify the main menu, tutorial, rules, card study, and each changed game mode.
5. Open a pull request describing the motivation, behavior change, and manual tests performed.

## Style and quality

- Use clear, descriptive names.
- Keep UI labels consistent.
- Preserve responsive layout and keyboard accessibility.
- Avoid introducing dependencies without a clear benefit.
- Do not claim tests passed unless they were actually run.

## Reporting bugs

Include the browser and operating system, steps to reproduce, expected behavior, actual behavior, and screenshots when useful. Do not include real credentials, personal data, or sensitive incident evidence.
